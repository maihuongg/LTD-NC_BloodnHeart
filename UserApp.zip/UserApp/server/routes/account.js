// const express = require('express');
// const router = express.Router();
// const authMiddleware = require('../middlewares/auth');
// const accountController = require('../controllers/accountController');

// // Admin get all user

// module.exports = router;
